# AutoServer

Autoserver is a python library for making quick web UIs, it was originally made for HackEd 2023. 